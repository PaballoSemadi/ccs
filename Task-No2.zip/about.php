<!DOCTYPE html>
<html>
<head>
	<title>About Me</title>
	
    
    <link rel="stylesheet" type="text/css" href="styles.css">
		

</head>
<body>
  <div class="background">
  <span></span>
  <span></span>
  <span></span>
  <span></span>
  <span></span>
  <span></span>
  <span></span>
  <span></span>
  <span></span>
  <span></span>
  <span></span>
  <span></span>
  <span></span>
  <span></span>
  <span></span>
  <span></span>
  <span></span>
  <span></span>
  <span></span>
  <span></span>
</div>
	<div class="container">
		<h1><center>About Me</center></h1>
		<p><center><strong>My name is Paballo Semadi and I am a recent Computer Science and Information Technology Honours Graduate.I am passionate about technology and its ability to transform the world. My fascination with computers began at an early age and has only grown stronger over the years.</strong></center></p>
<br><br>
<p><center><strong>During my studies, I gained a broad knowledge of various programming languages such as PHP, C++,C#,JavaScript and Python. I also learned about various software development methodologies, computer networks, algorithms, and data structures. Additionally, I have experience in web development, database management, and operating systems.</strong></center></p><br><br>

<p><center><strong>Apart from my academic background, I have been involved in various projects that have allowed me to apply my knowledge to real-world problems. For instance,I was part of the Sefako Makgatho Health Sciences University ICT student technical support services team where i was employed as an Information communication technology student assistant.</strong></center></p><br><br>

<p><center><strong>I am always eager to learn new technologies and improve my skills. I believe that continuous learning is the key to success in the ever-changing tech industry. That's why I am always looking for new challenges and opportunities to expand my knowledge and expertise.</strong></center</p><br><br>

<p><center><strong>In my free time, I enjoy reading about new technologies and participating in online forums to discuss the latest trends in the tech industry. I also like to stay active and engage in outdoor activities like Football and cycling.</strong></center</p><br><br>

<p><center><strong>Thank you for taking the time to read about me. If you have any questions or would like to connect, please don't hesitate to reach out.
</strong></center</p>
	</div>
</body>
</html>
