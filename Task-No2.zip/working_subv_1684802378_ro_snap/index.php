<!DOCTYPE html>
<html>
<head>
	<title>Welcome to My Website</title>
</head>
<body>
	<h1>Welcome to My Website!</h1>
	<p>Thank you for visiting my website. Please take a moment to explore the site and See what i have to offer.</p>
	
	<h2>About Us</h2>
	<p>We are a team of web developers who are passionate about creating innovative and user-friendly websites. Our goal is to provide our clients with the highest quality websites that meet their needs and exceed their expectations.</p>
	
	<h2>Our Services</h2>
	<ul>
		<li>Website Design</li>
		<li>Website Development</li>
		<li>Search Engine Optimization</li>
		<li>Social Media Marketing</li>
		<li>E-commerce Solutions</li>
	</ul>
	
	<h2>Contact Us</h2>
	<p>If you have any questions or would like to discuss your website needs, please feel free to contact us using the information below:</p>
	
	<p>Phone: 555-555-5555</p>
	<p>Email: info@mywebsite.com</p>
	<p>Address: 123 Main Street, Anytown USA</p>
</body>
</html>
