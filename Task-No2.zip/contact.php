 <!DOCTYPE html>
<html>
<head>
	<title>Contact Me</title>
	
    
    <link rel="stylesheet" type="text/css" href="styles.css">
		

</head>
<body>
  <div class="background">
  <span></span>
  <span></span>
  <span></span>
  <span></span>
  <span></span>
  <span></span>
  <span></span>
  <span></span>
  <span></span>
  <span></span>
  <span></span>
  <span></span>
  <span></span>
  <span></span>
  <span></span>
  <span></span>
  <span></span>
  <span></span>
  <span></span>
  <span></span>
</div>
	<div class="container">

<div class="contact-card">
  
  <h2> Paballo Phenyo Hope</h2>
  <p> Email: paballo.semadi93@gmailcom </p>
  <p> Phone: 061-473-9083 </p>
  
  
</div>

      
</div>
</body>
</html>