<!DOCTYPE html>
<html>
<head>
  
  <title>My Website</title>
  <link rel="stylesheet" type="text/css" href="styles.css">
   
</head>
<style>
  


  
img {

   
  margin-left: auto;
  margin-right: auto;
  display: block;
  opacity: 10%
  margin-left: auto;
  margin-right: auto;
  height: 30%;
  max-width: 30%
} 
  
ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  border: 1px solid #e7e7e7;
  background-color: #f3f3f3;
}

li {
  float: left;
}

li a {
  display: block;
  color: #666;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover:not(.active) {
  background-color: #ddd;
}

li a.active {
  color: lightblue;
  background-color: #04AA6D;
}


</style>
<body>
<div class="box">
  <h2> </h2>
  <img src="paballo.png " class="center">
</div> 
  
  <div class="background">
  <span></span>
  <span></span>
  <span></span>
  <span></span>
  <span></span>
  <span></span>
  <span></span>
  <span></span>
  <span></span>
  <span></span>
  <span></span>
  <span></span>
  <span></span>
  <span></span>
  <span></span>
  <span></span>
  <span></span>
  <span></span>
  <span></span>
  <span></span>
</div>
  
  


  <nav>
    
  <div id="menu-outer">
  <div class="table">
    <ul id="horizontal-list">
    <li><a href="index.php">Home</a></li>
    <li><a href="about.php">About Me</a></li>
    <li><a href="contact.php">Contact</a></li>
  
  </ul>
    </div>
</div>
    
</nav>


  <footer>
    <div class="box"
    <p>&copy; 2023 Paballo Semadi.All rights</p>
    </div>
  </footer>
</body>
  
</body>
</html>
