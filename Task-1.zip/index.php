<!DOCTYPE html>
<html lang="en">
<head>
  <link rel="stylesheet" href="styles.css">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Task 1</title>
</head>
<body>
  <header>
    <div class="box"
    <h1><strong>Paballo and Associates</strong></h1>
      </div>
  </header>
  <main>
    <div class="box">
      <h2>About Us</h2>
      <p>Paballo Inc Is A Law Firm Established In 2023 By Mr Paballo Semadi.<br><br>
We Pride Ourselves In Delivering Excellent Services Through Our Hard Work. We Treat Each And Every Client With The Highest Level Of Respect And Priority.We Litigate In Various Divisions Of The High Court, Magistrates Court, Supreme Court Of Appeal And Where Necessary, The Constitutional Court.
Our Vision Is To Grow Into A Nationwide Institution That Provides Services Of Excellent Quality Across All Demographics.
</p>
    </div>
    <div class="box animated-box">
      <h2>Our Services</h2>
      <p>We Provide The Following Services:<br><br>

Commercial Litigation<br><br>

Drafting Of Contracts And Contractual Disputes<br><br>

Legal And Risk Compliance<br><br>

Family Law: Divorce And<br><br>

Personal Injury Claims. 
</p>
    </div>
  </main>

<div class="bg"></div>
<div class="bg bg2"></div>
<div class="bg bg3"></div>



  <footer>
    <div class="box"
    <p>&copy; 2023 Paballo Semadi. All rights reserved.</p>
       </div>
  </footer>
</body>
</html>
